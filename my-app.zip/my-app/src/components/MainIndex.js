import React, { Component} from 'react';

class MainIndex extends Component{
render(){
return(
    <main className="content-main">
          
    <div className="background-image">
      
            <div className="searcher-container container">
                <h1>Alquiler y venta de apartamentos y casas del Uruguay</h1>
                  <div class="searcher">               
                            <form>
                              <select className="form">
                                <option value="" selected>Ciudad</option>
                                <option>Montevideo</option>
                               
                              </select>
                      
                              <select className="form" placeholder="Casas, apartamentos">
                              <option value="" selected>Montevideo</option>
                                <option>Malvin</option>
                                <option>Centro</option>
                                <option>Carrasco</option>
                              </select>
                      
                              <input type="text" className="form" placeholder="Direccion" required></input>
                              <button className="orange_btn">Buscar</button>
                            </form>
                
                                <div>
                                    <div className="white-icon">
                                    <span className="fa fa-plus-circle"></span>
                                    <span className="font-white-searcher" >Buscar por referencia</span>
                                    </div>     
                                </div>         
                  </div>
            </div>
      </div>
    </main>
)}

}
export default MainIndex;