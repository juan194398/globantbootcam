import React, { Component} from 'react';
import { Link } from 'react-router-dom';

class HighlightsProperties extends Component{
     
    constructor(props) {
  super(props); 

  this.state = {
 properties: []
} 
this.handleGoToDescriptionClick = this.handleGoToDescriptionClick.bind(this);
}

componentDidMount(){
    this.fetchData();
}

fetchData(){
    fetch('http://localhost:3000/properties?highlighted=true')
            .then(response => response.json())
            .then(properties =>  this.setState({properties:properties}));
            }

  handleGoToDescriptionClick(e){
     
     <Link to='/SearchProperty'> </Link>
  }

    render(){
        return(

            <div className="highlights col-md-12 col-lg-12">
            <div className="highlights-bar col-md-12 col-lg-12">
                <h2>Busquedas Recomendadas</h2>
            </div>    
            <div className="contentHighlightsProperties container">
                {
                    this.state.properties.length > 0 ? this.state.properties.map(property => {
                      return( <div className= "HighlightsProperties" id={property.id}  > 
                              console.log({property.id});    
                             <Link to="/SearchProperty?id=">  <img src={property.images[0].name} /></Link>
                        </div>
                        )
                    }): null
                    }
                
            </div>
        </div> 
        )
    }
}

export default HighlightsProperties;