import React, { Component} from 'react';


class Footer extends Component {
    render(){
        return(

            <footer className="footer col-md-12">
            <p>Inmobiliaria Bootcamp S.R.L </p>
  
            <div className="icons_social_media_footer">
             <a href="https://es-la.facebook.com/InfoCasasUY/"><span className="fab fa-facebook"></span> </a>
             <a href="https://twitter.com/infocasasuy?lang=es"><span className="fab fa-twitter-square"></span></a>
             <a href="https://www.infocasas.com.uy/simulador-de-prestamos-hipotecarios/"> <span className="fa fa-home"></span></a>
            </div>
  
            <div className="nav-footer">
              <ul>
                <li>
                  <a href="index.html">Inicio ></a>
                </li>
                <li>
                  <a href="#">Ventas ></a>
                </li>
                <li>
                  <a href="#">Alquileres ></a>
                </li>
                <li>
                  <a href="#">Proyectos ></a>
                </li>
                <li>
                  <a href="#">Contactos ></a>
                </li>
              </ul>
            </div>
            <div>
              <a href="#"><span className="fas fa-chevron-circle-up icons_social_media_footer"></span></a>
            </div>
            <p>Copyright © 2018 Design</p>
          </footer>


        )
    }
}
export default Footer;