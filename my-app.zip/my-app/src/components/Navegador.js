import React, { Component } from 'react';
import logo from './logo_InfoCasas.png';

class Navegacion extends Component {
    render() {
        return (
            <div className="row">
                <header className="header container">

                    <div className="col-md-8">
                        <a href="app.js"><img src={logo} className="App-logo" alt="logo" /></a>
                        <span>
                            <a href="#">Ventas</a>
                            <a href="#">Alquiler</a>
                        </span>
                    </div>

                    <nav className="nav">
                        <div className="col-md-4">
                            <span>
                                <a href="#">contacto</a>
                                <button class="orange_btn btn btn-primary btn-sm" type="button">Publicar</button>
                                <a href="#">Iniciar sesion</a>
                            </span>
                        </div>
                    </nav>

                </header>
            </div>

        )

    }
}

export default Navegacion;