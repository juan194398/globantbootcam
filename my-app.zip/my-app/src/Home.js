import React, { Component } from 'react';
import MainIndex from './components/MainIndex';
import HighlightsProperties from './components/HighlightsProperties';

class Home extends Component {
   render(){
   	 return (
          <div className="HomeDiv">
              <MainIndex />
              <HighlightsProperties />
          </div>
   	 	);
   }

}

export default Home;