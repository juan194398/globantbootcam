import React, { Component } from 'react';
import './NavBar.css';
import logo from './img/logo1.png';

class NavBar extends Component {
  render(){
  	return(
           <header className="NavBar-header">
        <nav className="NavBar-nav">
            <div className="NavBar-div">
                <span className="NavBar-span">
                    <a  href="" className="NavBar-span">
                        <img src={logo} className="NavBar-logo" />
                    </a>
                    </span>
				<div className="NavBar-description">
                

                <span className="NavBar-descriptionSpan">Venta alquiler proyectos</span>
				</div>
				
            </div>
            <div className="NavBar-buttonConteiner">
                <button class="orange_btn" type="button">Publicar</button>
            </div>
        </nav>
    </header>

  		);


  }
}

export default NavBar;