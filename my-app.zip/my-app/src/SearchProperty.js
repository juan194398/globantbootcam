import React, { Component } from 'react';

class Search extends Component {
   render(){
   	 return (
          <div className="Prueba">
             <h1> ja </h1>
          </div>
   	 	);
   }

}

export default Search;