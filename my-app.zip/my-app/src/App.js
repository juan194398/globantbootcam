import React, { Component } from 'react';
import './App.css';
import PropTypes from 'prop-types';
import NavBar from './NavBar';
import Content from './Content';

import Navegacion from './components/Navegador';
import Footer from './components/Footer';



class App extends Component {
  static PropTypes= {
    children: PropTypes.object.isRequierd
  };

  render() {
    const { children } = this.props;
    return (
      <div className="App">
          <Navegacion />
         <Content body={children} />
         <Footer />
      </div>
    );
  }
}

export default App;
