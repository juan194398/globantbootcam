import React from 'react';
import { Route, Switch } from 'react-router-dom';

import App from './App.js';
import Home from './Home.js';
import Search from './SearchProperty.js';
import Detail from './DetailProperty.js'

const AppRoutes = () =>
 <App>
   <Switch>
     <Route path="/searchProperty" component={Search} />
     <Route path="/detailProperty" component={Detail} />
     <Route path="/" component={Home} />
   </Switch>
 </App>

 export default AppRoutes;