import React, { Component } from 'react';

class Detail extends Component {
   render(){
   	 return (
          <div className="Prueba">
             <h1> About </h1>
          </div>
   	 	);
   }

}

export default Detail;