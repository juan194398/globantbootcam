import React, { Component } from 'react';

class Contect extends Component {
 render(){
   const { body } = this.props;
     
     return (
        <div className= "Contect">
          {body}
        </div>
     	);

 }



}
 export default Contect;